import React from "react";
import "./style.css";

export const Element = () => {
  return (
    <div className="element">
      <div className="div-wrapper">
        <div className="group">
          <div className="div-wrapper">
            <div className="android-large">
              <div className="overlap">
                <div className="div">
                  <div className="overlap-group">
                    <div className="text-wrapper">Welcome to GameOn!</div>
                    <div className="text-wrapper-2">Level up your skills!</div>
                  </div>
                  <div className="rectangle" />
                  <img className="line" alt="Line" src="/img/line-1.svg" />
                  <div className="text-wrapper-3">Explore new languages</div>
                  <div className="rectangle-2" />
                  <div className="rectangle-3" />
                  <div className="rectangle-4" />
                  <div className="overlap-2">
                    <img className="img" alt="Line" src="/img/line-2.svg" />
                    <img className="line-2" alt="Line" src="/img/line-3.svg" />
                  </div>
                  <div className="overlap-3">
                    <div className="challenge-yourself">?&nbsp;&nbsp; Challenge yourself</div>
                    <p className="p">Track your progress and complete!</p>
                    <div className="overlap-4">
                      <div className="text-wrapper-4">Play now</div>
                    </div>
                  </div>
                  <div className="text-wrapper-5">Today’s challenge</div>
                  <div className="overlap-5">
                    <div className="text-wrapper-6">Italian cuisine</div>
                    <div className="text-wrapper-7">Delicious dishes to</div>
                    <div className="rectangle-5" />
                  </div>
                  <div className="text-wrapper-8">Engaging activities</div>
                  <div className="overlap-6">
                    <div className="text-wrapper-9">Reading</div>
                    <img className="download" alt="Download" src="/img/download-1.png" />
                  </div>
                  <div className="overlap-7">
                    <div className="text-wrapper-10">Listening</div>
                  </div>
                  <div className="overlap-8">
                    <div className="text-wrapper-11">Grammar</div>
                    <div className="text-wrapper-12">ABC</div>
                  </div>
                  <div className="overlap-group-2">
                    <div className="text-wrapper-13">Test your</div>
                  </div>
                </div>
                <img className="images" alt="Images" src="/img/images-1.png" />
                <img className="images-2" alt="Images" src="/img/images-1-1.png" />
                <img className="images-3" alt="Images" src="/img/images-2-1.png" />
                <img
                  className="pngtree-learning"
                  alt="Pngtree learning"
                  src="/img/pngtree-learning-foreign-languages-icons-many-colors-set-isolate-2.png"
                />
                <img
                  className="pngtree-learning-2"
                  alt="Pngtree learning"
                  src="/img/pngtree-learning-foreign-languages-icons-many-colors-set-isolate-1.png"
                />
                <img
                  className="pngtree-learning-3"
                  alt="Pngtree learning"
                  src="/img/pngtree-learning-foreign-languages-icons-many-colors-set-isolate.png"
                />
                <div className="rectangle-6" />
                <div className="text-wrapper-14">Start</div>
              </div>
              <div className="overlap-9">
                <img className="home-circle-icon" alt="Home circle icon" src="/img/home-circle-icon-137496-1.png" />
                <img className="download-2" alt="Download" src="/img/download-4-2.png" />
                <img className="images-4" alt="Images" src="/img/images-3-2.png" />
                <img className="ellipse" alt="Ellipse" src="/img/ellipse-5.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
