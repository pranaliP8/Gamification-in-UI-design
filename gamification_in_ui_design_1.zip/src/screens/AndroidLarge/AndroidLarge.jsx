import React from "react";
import "./style.css";

export const AndroidLarge = () => {
  return (
    <div className="android-large">
      <div className="div">
        <div className="rectangle" />
        <div className="overlap">
          <div className="group">
            <div className="group-2">
              <div className="overlap-group" />
              <div className="text-wrapper">Gaming Guru</div>
              <div className="text-wrapper-2">Gamer</div>
              <div className="text-wrapper-3">Level</div>
              <p className="XP">
                <span className="span">XP</span>
                <span className="text-wrapper-4">&nbsp;</span>
              </p>
              <p className="mission">
                <span className="span">Mission</span>
                <span className="text-wrapper-4">&nbsp;</span>
              </p>
              <div className="text-wrapper-5">Challenges</div>
              <div className="text-wrapper-6">Achievement</div>
              <div className="text-wrapper-7">Quests</div>
              <div className="div-wrapper">
                <div className="text-wrapper-8">chat</div>
              </div>
              <div className="overlap-group-2">
                <div className="text-wrapper-9">Join</div>
              </div>
              <div className="text-wrapper-10">Gallery of Adventure</div>
              <div className="text-wrapper-11">Game play Clip</div>
              <div className="text-wrapper-12">&gt;</div>
              <div className="overlap-2">
                <div className="text-wrapper-13">&gt;</div>
                <img className="istockphoto" alt="Istockphoto" src="/img/istockphoto-1334298602-640x640-1.png" />
              </div>
              <img className="home-circle-icon" alt="Home circle icon" src="/img/home-circle-icon-137496-1.png" />
              <img className="download" alt="Download" src="/img/download-4-2.png" />
              <img className="images" alt="Images" src="/img/images-3-2.png" />
              <img className="gamer" alt="Gamer" src="/img/gamer-2.png" />
              <img
                className="chess-board-with-all"
                alt="Chess board with all"
                src="/img/chess-board-with-all-chess-pieces-isolated-on-white-background-s.png"
              />
              <img
                className="traverse-for-a"
                alt="Traverse for a"
                src="/img/traverse-for-a-private-epic-journey-to-langtang-2.png"
              />
              <img
                className="lovepik-father-and"
                alt="Lovepik father and"
                src="/img/lovepik-father-and-son-play-games-png-image-401928474-wh1200-1.png"
              />
            </div>
          </div>
          <div className="rectangle-2" />
          <div className="text-wrapper-14">Logout</div>
          <img className="img" alt="Images" src="/img/images-3.png" />
        </div>
      </div>
    </div>
  );
};
